A CRM Application for The Chai Shop & Co
==============================================

Salesforce + VS Code starter source code.

Folder structure:
- force-app/main/default/classes/CustomerController.cls
- force-app/main/default/lwc/customerManager/
- sfdx-project.json

IMPORTANT:
The Apex code expects these Salesforce API names:
Object: Customer__c
Fields: Phone__c, Email__c

If your Salesforce object/field API names are different, replace them in CustomerController.cls.

Basic deployment:
1. Open this folder in VS Code.
2. Make sure Salesforce CLI is installed.
3. Authorize your Salesforce org.
4. Deploy source to your org.
5. Add the customerManager LWC to a Lightning App/Home/Record Page.

This is a starter project and can be extended with Products, Orders, Payments,
Reports and Dashboards.
