import { LightningElement } from 'lwc';
import createCustomer from '@salesforce/apex/CustomerController.createCustomer';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class CustomerManager extends LightningElement {
    customerName = '';
    phone = '';
    email = '';

    handleNameChange(event) {
        this.customerName = event.target.value;
    }

    handlePhoneChange(event) {
        this.phone = event.target.value;
    }

    handleEmailChange(event) {
        this.email = event.target.value;
    }

    handleCreate() {
        createCustomer({
            name: this.customerName,
            phone: this.phone,
            email: this.email
        })
        .then(() => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Customer created successfully!',
                    variant: 'success'
                })
            );

            this.customerName = '';
            this.phone = '';
            this.email = '';
        })
        .catch(error => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: error.body?.message || 'Something went wrong',
                    variant: 'error'
                })
            );
        });
    }
}
